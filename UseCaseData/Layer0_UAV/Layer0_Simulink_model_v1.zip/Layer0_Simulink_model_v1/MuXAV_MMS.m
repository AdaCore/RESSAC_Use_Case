%========================================================================
%                      WATERS 2018 Challenge
%                    MuXAV Multi-System model
%                         V1.0 (30/04/2018)
%
% Emmanuel Ledinot (Dassault Aviation)
% Thomas Loquen    (ONERA)
%
% MATLAB   versions:  2011a, 2017b
% Simulink versions:   V7.7,  V8.3
%========================================================================
%
%   This file defines the constants referenced in the Mission Management
%   System (MMS)

%%

% Empty mass of the drone as assumed by MMS software
PRM_MMS_EmptyMass=PRM_AV_mb;

% Electrical capacities as assumed by MMS
PRM_MMS_PrimaryCapacity   = 1000.0;
PRM_MMS_SecondaryCapacity =  200.0;

%desired pendulum inital angle
PRM_MMS_theta_d=85*pi/180;

% For control laws
lr=PRM_AV_lr;
mr=PRM_AV_mr;
lb=PRM_AV_lb;
mb=PRM_AV_mb;
g =PRM_ENV_g;
Ix=PRM_AV_Ix;

PRM_MMS_theta_dot_gain=(lr*mr/2+lb*mb)*g/Ix;

% F_FC / Climb
PRM_MMS_kpc=100;
PRM_MMS_kdc=20;
PRM_MMS_kphic=25;

% F_FC / Descent
PRM_MMS_kpd=20;
PRM_MMS_kdd=20;
PRM_MMS_kphid=25;

%%
save MuXAV_MMS.mat PRM_MMS_*

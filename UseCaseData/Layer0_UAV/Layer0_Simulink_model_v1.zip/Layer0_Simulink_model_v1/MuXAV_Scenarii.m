%========================================================================
%                      WATERS 2018 Challenge
%                    MuXAV Multi-System model
%                         V1.0 (30/04/2018)
%
% Emmanuel Ledinot (Dassault Aviation)
% Thomas Loquen    (ONERA)
%
% MATLAB   versions:  2011a, 2017b
% Simulink versions:   V7.7,  V8.3
%========================================================================
%
%   This file defines the input scenarii that stimulate the model:
%   - ground station commands
%   - field operator commands
%   - wind and icing disturbances on the AV mechanical body
%   - system failures (TBDL)

%%
% All parameters are defined at the highest rate: 50Hz
% The low-rate functions have to subsample the input streams

Hf=50;                 % Hz (baseline rate)
timeline=0:(1/Hf):70;

% Duration of the preflight phases: 10s (common to the 4 scenarios)
% Duration of the flight phases:    60s (common to the 4 scenarios)
PreflightDuration = 10;
FlightDuration    = 60;
CycleNB = (PreflightDuration + FlightDuration)*Hf + 1;

%%
%==========               MISSION PARAMETERS                 ===========

%  All the user-related constants are in aeronautical units (ft, kt, nm, lb)
%  All the computations of the model are in SI units (m, m/s, kg, J, W)

% 1 ft =  0.3048 m
% 1 kt =  0.5144 m/s
% 1 lb =  0.4536 kg
% 1 nm =sgc_co  1852   m

% Payload
MIS_PRM_MinMass      =  0.0;
MIS_PRM_MaxMass      = 10.0;   

% Mission 
MIS_PRM_MinDistance  =  0.1;
MIS_PRM_MaxDistance  = 10.0;   

MIS_PRM_MinAltitude  =  300.0;
MIS_PRM_MaxAltitude  = 3000.0; 

MIS_PRM_MinSpeed     =    0.0;
MIS_PRM_MaxSpeed     =  100.0;

% Electrical energy sources
MIS_PRM_PrimaryCapacity   = 1000.0;
MIS_PRM_SecondaryCapacity =  200.0;

% Scenario 1: Nominal
MIS_PRM_Mass1 =    5.0;   % Payload mass
MIS_PRM_Dist1 =    5.0;   % Mission range (payload delivery)
%MIS_PRM_Alt1  = 1500.0;   % Flight level = cruise altitude (Thomas' fix)
MIS_PRM_Alt1  = 500.0;   % Flight level = cruise altitude
MIS_PRM_Spd1  =   50.0;   % Ground speed

% Scenario 2: Bad weather and no component failure
MIS_PRM_Mass2 = MIS_PRM_Mass1;   
MIS_PRM_Dist2 = MIS_PRM_Dist1;   
MIS_PRM_Alt2  = 1.5 * MIS_PRM_Alt1;   
MIS_PRM_Spd2  = 2.0 * MIS_PRM_Spd1;  

% Scenario 3: Good weather and a few component failures
MIS_PRM_Mass3 = 2.0 * MIS_PRM_Mass1;   
MIS_PRM_Dist3 = 2.0 * MIS_PRM_Dist1;   
MIS_PRM_Alt3  = 2.0 * MIS_PRM_Alt1;   
MIS_PRM_Spd3  = MIS_PRM_Spd2;

% Scenario 4: Bad weather and many component failures
MIS_PRM_Mass4 = MIS_PRM_Mass3;   
MIS_PRM_Dist4 = MIS_PRM_Dist3;   
MIS_PRM_Alt4  = MIS_PRM_Alt3;   
MIS_PRM_Spd4  = MIS_PRM_Spd3; 

%% 
%==============   NAVIGATION MODE OPTION PARAMETERS       =============

% MODE: defines whether the ground station controls the navigation
% parameters or not

% OPTION: defines which kinematic parameter or criterion is used for
% regulation (so-called "flight control laws")

LBL_NavMode_Undefined      = 0;
LBL_NavMode_A              = 1;   % Autonomous
LBL_NavMode_RP             = 2;   % Ground Control

LBL_NavOption_Undefined    = 0;
LBL_NavOption_ALTITUDE     = 1;   % Alphabetic order numbering 
LBL_NavOption_ENERGY       = 2;
LBL_NavOption_SPEED        = 3;

LBL_CpModeSwitch_A         = 1;
LBL_CpModeSwitch_RP        = 2;
LBL_CpBaySwitch_CLOSED     = 1;
LBL_CpBaySwitch_OPEN       = 2;

 
%%  
%==========               EXTERNAL EVENTS                     ===========

%----             Field Operator - CONTROL PANEL                    -----

%      Scenario 1

% Electrical Power
ScIn_CP_ONOFF_PushButton=...
horzcat(sgc_co(00,0,02),...
        sgc_cc(02,1,70));
ScIn_CP_ONOFF_PushButton=horzcat(timeline',ScIn_CP_ONOFF_PushButton');

% Payload Installation
ScIn_CP_BaySwitch=...
horzcat(sgc_co(00,0,01),...
        sgc_co(01,LBL_CpBaySwitch_CLOSED,04),...
        sgc_co(04,LBL_CpBaySwitch_OPEN,  08),...
        sgc_cc(08,LBL_CpBaySwitch_CLOSED,70));
ScIn_CP_BaySwitch=horzcat(timeline',ScIn_CP_BaySwitch');   
      
ScIn_CP_Rotator1=...
horzcat(sgc_co(00,0,02),...
        sgc_cc(02,0,70));
ScIn_CP_Rotator1=horzcat(timeline',ScIn_CP_Rotator1');
    
ScIn_CP_Rotator2=...
horzcat(sgc_co(00,0,02),...
        sgc_cc(02,5,70)); 
ScIn_CP_Rotator2=horzcat(timeline',ScIn_CP_Rotator2');

% Connection to the ground station ('RP') or not ('A')
ScIn_CP_ModeSwitch=...
horzcat(sgc_co(00,0,03),...
        sgc_cc(03,LBL_CpModeSwitch_A,70));
ScIn_CP_ModeSwitch=horzcat(timeline',ScIn_CP_ModeSwitch');

% Upload of the mission parameters 
%
% Note: fix of a spec bug (omission of the Option value in the content of 
% the USB key. In the model, the option is part of the uploaded data
% Another fix could have been a defautlt option (e.g SPEED) hardwired
% in the drone's software
% The Operational and Functional specification documents have 
% to be synchronized with the model

% Distance
ScIn_CP_USB_Key_Distance=...
horzcat(sgc_co(00,        0,05),...
        sgc_co(05,MIS_PRM_Dist1,09),...
        sgc_cc(09,        0,70));    
ScIn_CP_USB_Key_Distance=horzcat(timeline',ScIn_CP_USB_Key_Distance');

% Speed
ScIn_CP_USB_Key_Speed=...
horzcat(sgc_co(00,       0,05),...
        sgc_co(05,MIS_PRM_Spd1,09),...
        sgc_cc(09,       0,70));
ScIn_CP_USB_Key_Speed=horzcat(timeline',ScIn_CP_USB_Key_Speed');

% Altitude
ScIn_CP_USB_Key_Altitude=...
horzcat(sgc_co(00,       0,05),...
        sgc_co(05,MIS_PRM_Alt1,09),...
        sgc_cc(09,       0,70));
ScIn_CP_USB_Key_Altitude=horzcat(timeline',ScIn_CP_USB_Key_Altitude');

% Option 
ScIn_CP_USB_Key_Option=...
horzcat(sgc_co(00,                     0,05),...
        sgc_co(05,LBL_NavOption_ALTITUDE,09),...
        sgc_cc(09,                     0,70));
ScIn_CP_USB_Key_Option=horzcat(timeline',ScIn_CP_USB_Key_Option');
% End of USB Key

ScIn_CP_START_PushButton=...
horzcat(sgc_co(00,0,12),...
        sgc_cc(12,1,70));
ScIn_CP_START_PushButton=horzcat(timeline',ScIn_CP_START_PushButton');    

%%
%----               GROUND STATION Operator                         -----

% The messages stop beeing emitted when flight begins (GO event)
% In the model there is time-triggered emission end (t=25s),
% but it should be event-triggered

% Scenario 1 ('A' mode, the messages are ignored)

ScIn_GS_NavigationMode=...
horzcat(sgc_co(00,LBL_NavMode_Undefined,04),...
        sgc_co(04,LBL_NavMode_A,        25),...
        sgc_cc(25,LBL_NavMode_Undefined,70));
ScIn_GS_NavigationMode=horzcat(timeline',ScIn_GS_NavigationMode');

% Left undefined because the GS is not connected
ScIn_GS_NavigationOption=...
        sgc_cc(00,LBL_NavOption_Undefined,70);
ScIn_GS_NavigationOption=horzcat(timeline',ScIn_GS_NavigationOption');

% Mission parameters: transmitted permanently but ignored by the drone
ScIn_GS_MissionDistance=...
horzcat(sgc_co(00,        0,03),...
        sgc_cc(03,MIS_PRM_Dist1,70));    
ScIn_GS_MissionDistance=horzcat(timeline',ScIn_GS_MissionDistance');

ScIn_GS_MissionSpeed=...
horzcat(sgc_co(00,       0,08),...
        sgc_cc(08,MIS_PRM_Spd1,70));    
ScIn_GS_MissionSpeed=horzcat(timeline',ScIn_GS_MissionSpeed');

ScIn_GS_MissionAltitude=...
horzcat(sgc_co(00,       0,11),...
        sgc_cc(11,MIS_PRM_Alt1,70));    
ScIn_GS_MissionAltitude=horzcat(timeline',ScIn_GS_MissionAltitude');
% End of mission definition

ScIn_GS_GO=...
horzcat(sgc_co(00,0,11),...
        sgc_cc(11,1,70));
ScIn_GS_GO=horzcat(timeline',ScIn_GS_GO');

ScIn_GS_EmergencyLanding=...
        sgc_cc(00,0,70);
ScIn_GS_EmergencyLanding=horzcat(timeline',ScIn_GS_EmergencyLanding'); 

%%
%==========              EXTERNAL SIGNALS                     ===========

%%
%----                   Wind Conditions                            ------
%               Horizontal and Vertical Components 
%                   (average amplitude period) 

MIS_PRM_MinCrosswind = 0.0; 
MIS_PRM_MaxCrosswind = 25.0; 

% Standard 
SHavg = 15.0; 
SHamp =  5.0;
SHprd = 20.0;
SVavg =  0.0;
SVamp = 10.0;
SVprd = 10.0;

%  Good    
GHavg = -5.0;
GHamp =  5.0;
GHprd = 20.0;
GVavg =  0.0;
GVamp =  5.0;
GVprd = 20.0;

% Adverse 
AHavg = -25.0;
AHamp =  10.0;
AHprd =   5.0;
AVavg = -15.0;
AVamp =   5.0;
AVprd =   3.0;

ENV_SWC_HorizontalWind    = SHavg*ones(1,CycleNB) + SHamp*(1+randn(1,CycleNB)) .* cos(2*pi*(ones(1,CycleNB)./(Hf*SHprd)));
ENV_SWC_VerticalWind      = SVavg*ones(1,CycleNB) + SVamp*(1+randn(1,CycleNB)) .* cos(2*pi*(ones(1,CycleNB)./(Hf*SVprd))); 
ENV_GWC_HorizontalWind    = GHavg*ones(1,CycleNB) + GHamp*(1+randn(1,CycleNB)) .* cos(2*pi*(ones(1,CycleNB)./(Hf*GHprd)));
ENV_GWC_VerticalalWind    = GVavg*ones(1,CycleNB) + GVamp*(1+randn(1,CycleNB)) .* cos(2*pi*(ones(1,CycleNB)./(Hf*GVprd)));
ENV_AWC_HorizontalWind    = AHavg*ones(1,CycleNB) + AHamp*(1+randn(1,CycleNB)) .* cos(2*pi*(ones(1,CycleNB)./(Hf*AHprd)));
ENV_AWC_VerticalalWind    = AVavg*ones(1,CycleNB) + AVamp*(1+randn(1,CycleNB)) .* cos(2*pi*(ones(1,CycleNB)./(Hf*AVprd)));

ENV_SWC_HorizontalWind    = horzcat(timeline',ENV_SWC_HorizontalWind');
ENV_SWC_VerticalWind      = horzcat(timeline',ENV_SWC_VerticalWind');

%%
%-----            Icing Conditions (Standard, Good, Adverse)          -----

% Dates in seconds
Ice_begin1 =  20.0;
Ice_end1   =  30.0;
Ice_begin2 =  60.0;
Ice_end2   =  65.0;

% TBDL
ENV_SWC_Icing = zeros(1,CycleNB);
ENV_GWC_Icing = zeros(1,CycleNB);
ENV_AWC_Icing = zeros(1,CycleNB);

ENV_SWC_Icing = horzcat(timeline',ENV_SWC_Icing');

%%
save MuXAV_Scenarii.mat MIS_PRM_* ScIn_* ENV_*
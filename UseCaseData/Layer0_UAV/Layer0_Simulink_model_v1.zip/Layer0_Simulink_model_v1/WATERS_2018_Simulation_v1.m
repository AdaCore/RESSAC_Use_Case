%========================================================================
%                      WATERS 2018 Challenge
%                    MuXAV Multi-System model
%                         V1.0 (30/04/2018)
%
% Emmanuel Ledinot (Dassault Aviation)
% Thomas Loquen (ONERA)
%========================================================================

% This file loads all the constants defined in MuXAV_Multi-system.m and
% used by MuXAV_Multi-system.mdl
%
% Tested MATLAB  versions:   2011a, 2017b
% Tested Simulink version:    V7.7,  V8.3

%%
% Builds the global init file from the local init files

load MuXAV_Buses.mat   
load MuXAV_Body.mat
load MuXAV_EPS.mat
load MuXAV_HBS.mat
load MuXAV_MMS.mat

load MuXAV_Scenarii.mat

%%
save('WATERS_2018_Simulation_v1.mat');

%========================================================================
%                      WATERS 2018 Challenge
%                    MuXAV Multi-System model
%                         V1.0 (30/04/2018)
%
% Emmanuel Ledinot (Dassault Aviation)
% Thomas Loquen (ONERA)
%
% MATLAB   versions:  2011a, 2017b
% Simulink versions:   V7.7,  V8.3
%========================================================================
%
% This file defines the constants of the Hydraulic Braking System (HBS)

%%
% ECU: Transfer functions: torque command -> Pressure -> torque
% Torque cmd to pressure command
PRM_HBS_Nm2B=10;

% Electrical Pump transfer function: the state space representation 
% is identical to that of the EPS/DC motors
PRM_HBS_KdeltaP=10;
PRM_HBS_kp=20;
PRM_HBS_kd=20;
PRM_HBS_kphi=25;
PRM_HBS_taudeltaP=0.01;

PRM_HBS_J=0.001;
PRM_HBS_b=0.1;
PRM_HBS_K=0.01; % Ke=Kt=K %modify K to change the dynamical behaviour
PRM_HBS_R=1;
PRM_HBS_L=0.5;

b=PRM_HBS_b;
J=PRM_HBS_J;
K=PRM_HBS_K;
R=PRM_HBS_R;
L=PRM_HBS_L;

% State space representation X=[tetadot i]
% Torque T=Kt*I
PRM_HBS_Adcc = [-b/J   K/J;
                -K/L  -R/L];
PRM_HBS_Bdcc = [0;
               1/L];
PRM_HBS_Cdcc = [1 0;
                0 K;
                0 1]; 
PRM_HBS_Ddcc = [0; 0; 0 ];

Adcc=PRM_HBS_Adcc;
Bdcc=PRM_HBS_Bdcc;
Cdcc=PRM_HBS_Cdcc;
Ddcc=PRM_HBS_Ddcc;

PRM_HBS_P_motor = ss(Adcc,Bdcc,Cdcc,Ddcc);

% PID commanding the pump's motor
PRM_HBS_Kp_m = 1000;
PRM_HBS_Ki_m = 20;
PRM_HBS_Kd_m= 100;

% Pump electrical consumption table
PRM_HBS_abs_V2I=[0 2 5 20];
PRM_HBS_ord_V2I=[0 0 300 1400];

% Dynamics of the Hydraulic Accumulator
PRM_HBS_tauAccu=3;
PRM_HBS_KAccu=10;
PRM_HBS_init_pressure=pi;

% Actuator's transfer function 
PRM_HBS_abs_cons=[0 2   5   20];
PRM_HBS_ord_cons=[0 0 300 1400];

% Braking clutches: Pressure to Torque transfer function
PRM_HBS_abs_P2T=[0 2 5 20];
PRM_HBS_ord_P2T=[0 2 4  5];

%%
save MuXAV_HBS.mat PRM_HBS_*

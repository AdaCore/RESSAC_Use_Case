%========================================================================
%                      WATERS 2018 Challenge
%                    MuXAV Multi-System model
%                         V1.0 (30/04/2018)
%
% Emmanuel Ledinot (Dassault Aviation)
% Thomas Loquen (ONERA)
%
% MATLAB   versions:  2011a, 2017b
% Simulink versions:  V7.7, V8.3
%========================================================================
%
% This file defines the constants used in the model of the mechanical body
%
%%
%

% Version without perturbations (wind & ice)

PRM_AV_mb=0.117;    % mass of the bob - end of the pendulum
PRM_AV_mr=0.044;    % mass of the shaft
PRM_AV_lb=0.254;    % length to the bob from the shaft
PRM_AV_lr=0.235;    % length of the shaft
PRM_AV_Ix=0.00845;  % inertia about x axis
PRM_AV_Ifz=0.01384; % inertia about the z axis - rotational
PRM_ENV_g=9.81;

% Simulation
PRM_AV_phidot0=0;        % rotational rate
PRM_AV_phi0=0;           % rotation angle
PRM_AV_thetadot0=0;      % angular rate
PRM_AV_theta0=30*pi/180; % pendulum initial angle
 

%%
save MuXAV_Body.mat PRM_AV_* PRM_ENV_*
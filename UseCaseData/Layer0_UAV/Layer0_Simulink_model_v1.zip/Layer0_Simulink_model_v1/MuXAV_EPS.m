%========================================================================
%                      WATERS 2018 Challenge
%                    MuXAV Multi-System model
%                         V1.0 (30/04/2018)
%
% Emmanuel Ledinot (Dassault Aviation)
% Thomas Loquen    (ONERA)
%
% MATLAB   versions:  2011a, 2017b
% Simulink versions:   V7.7,  V8.3
%========================================================================
%
% This file defines the constants of the Electrical Propulsion System (EPS)

%%
%     Batteries
%Primary capacity
PRM_EPS_PSC=1000;  % (J)
%Secondary capacity
PRM_EPS_SSC=200;   % (J)
%Table look-up: voltage as function of current consumption
PRM_EPS_abs_C2V=[0 250 1000];
PRM_EPS_ord_C2V=[0 28 28];

%%
%     Controller (ECU)
% Nm to Voltage 
PRM_EPS_Nm2V=10;
% F_EM: threshold to pressurize the H-accumulator (HBS)
PRM_EPS_accu_min_pressure=pi;

%%
%     DC motors
% (J)     moment of inertia of the rotor     0.01 kg.m^2
% (b)     motor viscous friction constant    0.1 N.m.s
% (Ke)    electromotive force constant       0.01 V/rad/sec
% (Kt)    motor torque constant              0.01 N.m/Amp
% (R)     electric resistance                1 Ohm
% (L)     electric inductance                0.5 H

PRM_EPS_J=0.001;
PRM_EPS_b=0.1;
PRM_EPS_K=0.01; % Ke=Kt=K %modify K to change the dynamical behaviour
PRM_EPS_R=1;
PRM_EPS_L=0.5;

b=PRM_EPS_b;
J=PRM_EPS_J;
K=PRM_EPS_K;
R=PRM_EPS_R
L=PRM_EPS_L;

% State space representation X=[tetadot i]
% Torque T=Kt*I
PRM_EPS_Adcc = [-b/J   K/J;
                -K/L  -R/L];
PRM_EPS_Bdcc = [0;
               1/L];
PRM_EPS_Cdcc = [1 0;
                0 K;
                0 1]; 
PRM_EPS_Ddcc = [0; 0; 0 ];

Adcc=PRM_EPS_Adcc;
Bdcc=PRM_EPS_Bdcc;
Cdcc=PRM_EPS_Cdcc;
Ddcc=PRM_EPS_Ddcc;

PRM_EPS_P_motor = ss(Adcc,Bdcc,Cdcc,Ddcc);

% PID control
PRM_EPS_Kp_m = 1000;
PRM_EPS_Ki_m = 20;
PRM_EPS_Kd_m= 100;

%%
save MuXAV_EPS.mat PRM_EPS_*
     

